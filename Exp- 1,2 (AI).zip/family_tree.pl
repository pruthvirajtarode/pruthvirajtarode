% Family Tree in Prolog

% Facts
parent(john, mike).
parent(john, mary).
parent(mary, sophia).
parent(mike, alice).
parent(mike, david).
parent(alice, kevin).

% Rules
ancestor(X, Y) :- parent(X, Y).
ancestor(X, Y) :- parent(X, Z), ancestor(Z, Y).

sibling(X, Y) :- parent(Z, X), parent(Z, Y), X \= Y.

grandparent(X, Y) :- parent(X, Z), parent(Z, Y).
grandchild(X, Y) :- grandparent(Y, X).

uncle(X, Y) :- sibling(X, Z), parent(Z, Y), male(X).
aunt(X, Y) :- sibling(X, Z), parent(Z, Y), female(X).

cousin(X, Y) :- parent(A, X), parent(B, Y), sibling(A, B).

% Gender info for uncle/aunt
male(john).
male(mike).
male(david).
male(kevin).

female(mary).
female(sophia).
female(alice).
