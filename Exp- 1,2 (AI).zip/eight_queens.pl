% 8 Queens Problem in Prolog

% Solve using permutation and safety rules
solve_8_queens(Qs) :-
    permutation([1,2,3,4,5,6,7,8], Qs),
    safe(Qs).

% Check diagonal safety
safe([]).
safe([Q|Qs]) :-
    safe(Qs, Q, 1),
    safe(Qs).

safe([], _, _).
safe([Q|Qs], Q0, D) :-
    Q0 =\= Q + D,
    Q0 =\= Q - D,
    D1 is D + 1,
    safe(Qs, Q0, D1).

% Print board
print_board(Qs) :-
    forall(nth1(Row, Qs, Col),
        (forall(between(1, 8, C),
            (C =:= Col -> write(' Q') ; write(' .'))),
         nl)).

% Get all solutions
all_8_queens(Qs) :- solve_8_queens(Qs).
