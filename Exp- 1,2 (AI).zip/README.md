# 🤖 AI Experiments in Prolog

This repository contains two classic **Artificial Intelligence experiments** implemented in **Prolog**:

1. 🌳 **Family Tree Case Study** – Knowledge Representation & Reasoning  
2. ♟️ **8 Queens Puzzle** – Backtracking and Constraint Solving  

Both experiments demonstrate the power of Prolog in **logic programming**, **knowledge representation**, and **problem solving**.

---

## 🌳 Experiment 1 – Family Tree Case Study

### 📖 Description
This project defines a **family tree knowledge base** in Prolog, with facts like `parent/2`, and rules to infer relationships such as:
- Ancestor & Descendant  
- Sibling  
- Grandparent & Grandchild  
- Uncle & Aunt  
- Cousin  

It demonstrates **knowledge representation** and **recursive reasoning** in Prolog.

### ▶️ Example Queries
```prolog
?- ancestor(john, alice).
true.

?- sibling(mike, X).
X = mary.

?- grandparent(X, sophia).
X = john ;
X = mary.
```

---

## ♟️ Experiment 2 – 8 Queens Puzzle

### 📖 Description
The **8 Queens problem** asks: "How can 8 queens be placed on a chessboard so that none attack each other?"  
This project solves it in Prolog using **backtracking + diagonal safety constraints**.

### 🚀 Features
- Generates **all 92 valid solutions**  
- Uses `permutation/2` with safety rules  
- Provides a **board printer** for visualization  

### ▶️ Example Queries
```prolog
?- solve_8_queens(Qs).
Qs = [1, 5, 8, 6, 3, 7, 2, 4] ;
Qs = [1, 6, 8, 3, 7, 4, 2, 5] ;
...

?- solve_8_queens(Qs), print_board(Qs).
. Q . . . . . .
. . . Q . . . .
Q . . . . . . .
. . . . . Q . .
. . Q . . . . .
. . . . . . Q .
. . . . Q . . .
. . . . . . . Q
```

---

## 🛠️ Requirements
- **SWI-Prolog** (tested with v9.x)  
  Download: [https://www.swi-prolog.org/Download.html](https://www.swi-prolog.org/Download.html)

---

## ▶️ How to Run
1. Clone/download this repository:
   ```bash
   git clone https://github.com/your-username/ai-prolog-experiments.git
   cd ai-prolog-experiments
   ```

2. Run **Family Tree**:
   ```prolog
   ?- ['family_tree.pl'].
   ?- ancestor(john, alice).
   ```

3. Run **8 Queens**:
   ```prolog
   ?- ['eight_queens.pl'].
   ?- solve_8_queens(Qs).
   ?- solve_8_queens(Qs), print_board(Qs).
   ```

---

## 📂 Project Structure
```
ai-prolog-experiments/
│
├── family_tree.pl        # Family tree knowledge base & rules
├── eight_queens.pl       # 8 queens solver & printer
├── README.md             # Documentation
├── .gitignore            # Git ignore file
```

---

## 🙌 Credits
- Developed in **Prolog** for AI Laboratory Experiments  
- Family Tree: Demonstrates **knowledge representation**  
- 8 Queens: Demonstrates **backtracking search & constraint solving**
